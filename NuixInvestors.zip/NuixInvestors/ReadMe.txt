Application:
This is a .Net Core 3.1 Web API with an Angular UI, and a simple SQL Express Relational DB. 

The API can be run stand alone. The UI was added to help display the functionality of the Web API.

This was developed with a Code-First approach, and the SQL DB and tables will be created and populated upon first run. 

The application was built to be opened in Visual Studio and ran with the Visual Studio IIS Express. 

Prerequisites:
* .Net Core 3.1 SDK
* Node.js 

Below is the implemented API calls

Get list of users:
Call: https://localhost:44384/api/client
Returns: List of User Id's and Full Names

Get a list of current investments for the user:
As an API user, I want to be able to query the list of investments for a user. The query should return the investment id and name.
Call: https://localhost:44384/api/client/GetPortfolio/{ClientId}
Returns: List of Distinct Stock Names and their Id's

Get details for a user's investment:
As an API user, I want to be able to query the details of a specific investment for a user. 
The query should return the number of shares, cost basis per share, current value, current price, term, and total gain/loss.
Call: https://localhost:44384/api/client/GetStockDetails/{clientId}/{stockId}
Returns: Stock Name, Number of Shares, Total Gain/Loss or Sum of all shares gains/loss, Current Stock Price, And a list of all Shares 
with their Purchase Date, Purchase Price, Gain/Loss since purchase, and term

Definitions:
*Cost basis per share: this is the price of 1 share of stock at the time it was purchased
*Current value: this is the number of shares multiplied by the current price per share
*Current price: this is the current price of 1 share of the stock
*Term: this is how long the stock has been owned. <=1 year is short term, >1 year is long term
*Total gain or loss: this is the difference between the current value, and the amount paid for all shares when they were purchased
