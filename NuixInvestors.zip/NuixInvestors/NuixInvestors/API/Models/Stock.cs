﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace NuixInvestors.API.Models
{
    public class Stock
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long StockId { get; set; }
        public string StockAbbr { get; set; }
        public string StockName { get; set; }

        public decimal CurrentPrice { get; set; }        
    }
}
