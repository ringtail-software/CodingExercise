﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace NuixInvestors.API.Models
{
    public class Client
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long ClientId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public DateTime JoinDate { get; set; }

        public string FullName { get { return this.FirstName + " " + this.LastName; } }

        public List<Portfolio> Portfolio { get; set; }
    }
}
