﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace NuixInvestors.API.Models
{
    public class Portfolio
    {
        public long PortfolioId { get; set; }
        public long StockId { get; set; }
        public Stock Stock { get; set; }


        public decimal PurchasePrice { get; set; }
        public DateTime PurchaseDate { get; set; }

        public string Term
        {
            get
            {
                if ((DateTime.Now - this.PurchaseDate).TotalDays > 365)
                    return "Long Term (" + Math.Floor(((DateTime.Now - this.PurchaseDate).TotalDays) / 365) + " years)";
                return "Short Term (" + Math.Floor((DateTime.Now - this.PurchaseDate).TotalDays) + " days)";
            }
        }

        [NotMapped]
        public decimal Gains { get; set; }

        // Lazy Load Related Client
        public long ClientId { get; set; }
        public Client Client { get; set; }
    }
}
