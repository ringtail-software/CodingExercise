﻿using Microsoft.EntityFrameworkCore;
using NuixInvestors.API.Models;

namespace NuixInvestors.API.Data
{
    public class NuixContext : DbContext
    {
        public NuixContext (DbContextOptions<NuixContext> options)
            : base(options)
        {
        }

        public DbSet<Stock> Stocks { get; set; }
        public DbSet<Portfolio> Portfolios { get; set; }
        public DbSet<Client> Clients { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Stock>().ToTable("Stocks");
            modelBuilder.Entity<Portfolio>().ToTable("Portfolios");
            modelBuilder.Entity<Client>().ToTable("Clients");
        }
    }
}
