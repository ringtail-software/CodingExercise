﻿using NuixInvestors.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NuixInvestors.API.Data
{
    public class DbInitializer
    {
        public static void Initialize(NuixContext context)
        {
            context.Database.EnsureCreated();

            // Look for any students.
            if (context.Clients.Any())
            {
                return;   // DB has been seeded
            }

            var clients = new Client[]
            {
            new Client{ClientId=12345,FirstName="John",LastName="Doe",JoinDate=DateTime.Parse("2017-10-04")},
            new Client{ClientId=98765,FirstName="Jane",LastName="Smith",JoinDate=DateTime.Parse("2018-02-19")}
            };
            foreach (Client c in clients)
            {
                context.Clients.Add(c);
            }
            context.SaveChanges();            

            var stocks = new Stock[]
            {
            new Stock{StockId=1,StockAbbr="ABC",StockName="Google",CurrentPrice=12.34m},
            new Stock{StockId=2,StockAbbr="AAPL",StockName="Apple",CurrentPrice=22.04m},
            new Stock{StockId=3,StockAbbr="F",StockName="Ford",CurrentPrice=8.24m},
            new Stock{StockId=4,StockAbbr="DIS",StockName="Disney",CurrentPrice=15.75m},
            new Stock{StockId=5,StockAbbr="TSLA",StockName="Tesla",CurrentPrice=125.10m}
            };
            foreach (Stock s in stocks)
            {
                context.Stocks.Add(s);
            }
            context.SaveChanges();

            var portfolios = new Portfolio[]
            {
            new Portfolio{StockId=1, ClientId=12345, PurchasePrice=3.25m,PurchaseDate=DateTime.Parse("2017-10-04")},
            new Portfolio{StockId=2, ClientId=12345, PurchasePrice=1.62m,PurchaseDate=DateTime.Parse("2018-05-29")},
            new Portfolio{StockId=1, ClientId=12345, PurchasePrice=0.62m,PurchaseDate=DateTime.Parse("2019-06-04")},
            new Portfolio{StockId=3, ClientId=12345, PurchasePrice=4.74m,PurchaseDate=DateTime.Parse("2020-10-15")},
            new Portfolio{StockId=5, ClientId=12345, PurchasePrice=5.18m,PurchaseDate=DateTime.Parse("2021-02-02")},

            new Portfolio{StockId=2, ClientId=98765, PurchasePrice=0.25m,PurchaseDate=DateTime.Parse("2018-02-20")},
            new Portfolio{StockId=4, ClientId=98765, PurchasePrice=32.05m,PurchaseDate=DateTime.Parse("2018-10-04")},
            new Portfolio{StockId=3, ClientId=98765, PurchasePrice=12.30m,PurchaseDate=DateTime.Parse("2019-01-01")},
            new Portfolio{StockId=3, ClientId=98765, PurchasePrice=5.99m,PurchaseDate=DateTime.Parse("2019-06-10")},
            new Portfolio{StockId=4, ClientId=98765, PurchasePrice=8.05m,PurchaseDate=DateTime.Parse("2020-10-12")},
            new Portfolio{StockId=2, ClientId=98765, PurchasePrice=18.05m,PurchaseDate=DateTime.Parse("2021-01-12")}
            };
            foreach (Portfolio p in portfolios)
            {
                context.Portfolios.Add(p);
            }
            context.SaveChanges();

        }
    }
}
