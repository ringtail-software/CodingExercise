﻿using Microsoft.Extensions.Logging;
using NuixInvestors.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NuixInvestors.API.Services
{
    public class PorfolioService
    {
        private ILogger Logger { get; set; }
        public List<Portfolio> CalculateGains(List<Portfolio> stocks)
        {
            try
            {
                stocks.ForEach(s =>
                {
                    s.Gains = s.Stock.CurrentPrice - s.PurchasePrice;
                });

                return stocks;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "An error while calculating gains/loss");
                return null;
            }
        }
    }
}
