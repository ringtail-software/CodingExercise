﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NuixInvestors.API.Data;
using NuixInvestors.API.Interfaces;
using NuixInvestors.API.Models;
using NuixInvestors.API.Services;

namespace NuixInvestors.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private ILogger Logger { get; set; }
        private readonly NuixContext _context;
        private IClient ClientRepo { get; set; }

        public ClientController(IClient _clientRepo, ILogger _logger)
        {
            //_context = context;
            ClientRepo = _clientRepo;
            this.Logger = _logger;
        }

        // GET: api/Client
        [HttpGet]
        public async Task<ActionResult> GetClients()
        {
            IEnumerable<Client> results = await ClientRepo.GetAll();

            return new JsonResult(results.OrderBy(c => c.LastName).Select(s => new { s.ClientId, s.FullName }).ToList());
        }

        // GET: api/Client/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Client>> GetClient(long id)
        {
            var client = await ClientRepo.GetClientSummary(id);

            if (client == null)
            {
                return NotFound();
            }

            return client;
        }

        // GET: api/Client/5
        [HttpGet("[action]/{id}")]
        public async Task<ActionResult> GetPortfolio(long id)
        {
            try
            {
                var client = await ClientRepo.GetClient(id);

                if (client?.Portfolio == null)
                {
                    return NotFound();
                }

                return new JsonResult(client.Portfolio?.Select(s => new { s.StockId, s.Stock.StockName }).ToList().Distinct().OrderBy(s => s.StockName));
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "An error while getting porfolio");
                return BadRequest("An error while getting porfolio");
            }
        }

        // GET: api/Client/5
        [HttpGet("[action]/{clientid}/{stockid}")]
        public async Task<ActionResult> GetStockDetails(long clientId, long stockId)
        {
            try
            {
                var client = await ClientRepo.GetClient(clientId);

                if (client == null)
                {
                    return NotFound("Client Not Found");
                }
                else if (client.Portfolio == null)
                {
                    return NotFound("Portfolio Not Found");
                }

                PorfolioService pService = new PorfolioService();
                List<Portfolio> updatedStocks = pService.CalculateGains(client.Portfolio?.Where(p => p.StockId == stockId).ToList());

                return new JsonResult(new
                {
                    Stock = updatedStocks.Select(s => s.Stock.StockName).FirstOrDefault(),
                    StockCount = updatedStocks.Count(),
                    CostBasis = updatedStocks.Select(s => new { s.PurchasePrice, s.PurchaseDate, s.Term, s.Gains }).ToList(),
                    CurrentPrice = updatedStocks.Select(s => s.Stock.CurrentPrice).FirstOrDefault(),
                    TotalGain = updatedStocks.Sum(s => s.Gains)
                });
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "An error while getting stock details");
                return BadRequest("An error while getting stock details");
            }
        }

        // PUT: api/Client/5
        // TODO: Not implemented for this excersise
        [HttpPut("{id}")]
        public async Task<IActionResult> PutClient(long id, Client client)
        {


            return NoContent();
        }

        // POST: api/Client
        // TODO: Not implemented for this excersise
        [HttpPost]
        public async Task<ActionResult<Client>> PostClient(Client client)
        {
            return NoContent();
        }

        // DELETE: api/Client/5
        // TODO: Not implemented for this excersise
        [HttpDelete("{id}")]
        public async Task<ActionResult<Client>> DeleteClient(long id)
        {
            return NoContent();
        }

        private bool ClientExists(long id)
        {
            return _context.Clients.Any(e => e.ClientId == id);
        }
    }
}
