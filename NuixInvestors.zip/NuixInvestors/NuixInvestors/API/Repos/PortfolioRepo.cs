﻿using NuixInvestors.API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NuixInvestors.API.Repos
{
    public class PortfolioRepo
    {
        private NuixContext _context;

        public PortfolioRepo(NuixContext context)
        {
            _context = context;
        }
    }
}
