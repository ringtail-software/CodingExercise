﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NuixInvestors.API.Data;
using NuixInvestors.API.Interfaces;
using NuixInvestors.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NuixInvestors.API.Repos
{
    public class ClientRepo : IClient
    {
        private NuixContext _context;
        private ILogger Logger { get; set; }

        public ClientRepo(NuixContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Client>> GetAll()
        {
            try
            {
                return await _context.Clients.ToListAsync();
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "An error while querying all Clients");
                return null;
            }
        }

        public async Task<Client> GetClientSummary(long id)
        {
            try
            {
                return await _context.Clients.FindAsync(id);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "An error while querying Client summary");
                return null;
            }
        }

        public async Task<Client> GetClient(long id)
        {
            try
            {
                return await _context.Clients
                                    .Include(s => s.Portfolio)
                                    .ThenInclude(p => p.Stock).FirstOrDefaultAsync(c => c.ClientId == id);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "An error while querying complete Clients");
                return null;
            }

        }
    }
}
