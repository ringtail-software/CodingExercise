﻿using NuixInvestors.API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NuixInvestors.API.Repos
{
    public class StockRepo
    {
        private NuixContext _context;

        public StockRepo(NuixContext context)
        {
            _context = context;
        }
    }
}
