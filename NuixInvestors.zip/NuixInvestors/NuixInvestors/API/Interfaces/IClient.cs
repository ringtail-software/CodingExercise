﻿using NuixInvestors.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NuixInvestors.API.Interfaces
{
    public interface IClient
    {
        Task<IEnumerable<Client>> GetAll();
        Task<Client> GetClient(long id);
        Task<Client> GetClientSummary(long id);
    }
}
