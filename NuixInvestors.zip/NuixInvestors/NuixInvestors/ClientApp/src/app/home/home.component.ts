import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent {
  public clients: Client[];
  public portfolio: any;
  public stockDetails: any;
  private clientId: number;

  public clientApiCall: string = '';
  public portfolioApiCall: string = '';
  public stockApiCall: string = '';

  constructor(private http: HttpClient, @Inject('BASE_URL') private baseUrl: string) {
    this.clientApiCall = baseUrl + 'api/client';
    http.get(baseUrl + 'api/client').subscribe((result: Client[]) => {
      this.clients = result;
    }, error => console.error(error));
  }

  getPortfolio(id: number) {
    this.portfolioApiCall = this.baseUrl + 'api/client/GetPortfolio/' + id;
    this.clientId = id;
    this.http.get(this.baseUrl + 'api/client/GetPortfolio/'+ id).subscribe(result => {
      this.portfolio = result;
      this.stockDetails = null;
    }, error => console.error(error));
  }

  getStockDetails(id: number) {
    this.stockApiCall = this.baseUrl + 'api/client/GetStockDetails/' + this.clientId + '/' + id;
    this.http.get(this.baseUrl + 'api/client/GetStockDetails/' + this.clientId + '/' + id).subscribe(result => {
      this.stockDetails = result;
    }, error => console.error(error));
  }
}

interface Client {  
  clientId: number;
  fullName: string;
}

